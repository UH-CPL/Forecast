//
//  ForecastManager.swift
//  Forecast
//
//  Created by Ioannis Pavlidis on 10/7/20.
//

import Foundation
import CoreLocation

protocol ForecastManagerDelegate {
    func didUpdateForecast(_ forecastManager: ForecastManager, weather: ForecastModel)
    func didFailWithError(error: Error)
}

struct ForecastManager {
    let forecastURL = "https://api.openweathermap.org/data/2.5/weather?appid=1f44e19409bedb8eaf650a10c64b4362&units=imperial"

    var delegate: ForecastManagerDelegate?
    
    func fetchForecast(cityName: String) {
        let urlString = "\(forecastURL)&q=\(cityName)"
        print(urlString)
        performRequest(with: urlString)
    }
    
    func fetchForecast(latitude: CLLocationDegrees, longitude: CLLocationDegrees) {
        let urlString = "\(forecastURL)&lat=\(latitude)&lon=\(longitude)"
        performRequest(with: urlString)
    }
    
    //NETWORKING PART
    func performRequest(with urlString: String) {
        //1. Create URL
        if let url = URL(string: urlString) {
            
            //2. Create URL session (acts like a browser)
            let session = URLSession(configuration: .default)
            
            //3. Give the session a task (in this case, it is a data task)
            //Instead of Closure: let task = session.dataTask(with: url, completionHandler: handle(data:response:error:))
            let task = session.dataTask(with: url) { (data, response, error) in
                if error != nil {
                    self.delegate?.didFailWithError(error: error!)
                    return
                }
                if let goodData = data {
                    if let weather = self.readJSON(goodData) {
                        self.delegate?.didUpdateForecast(self, weather: weather)
                    }
                }
            }
            task.resume()
        }
    }

    //DECODING PART
    func readJSON(_ forecastData: Data) -> ForecastModel? {
        let decoder = JSONDecoder()
        do {
            let decodedData = try decoder.decode(ForecastData.self, from: forecastData)
            let id = decodedData.weather[0].id
            let temp = decodedData.main.temp
            let name = decodedData.name
            
            let weather = ForecastModel(conditionId: id, cityName: name, temperature: temp)
            return weather
            
           // print(weather.cityName)
           //print(weather.conditionName)
           //print(weather.temperatureString)

        } catch {
            delegate?.didFailWithError(error: error)
            return nil
        }
    }

}
